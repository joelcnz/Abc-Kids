dmd -ofbin/Debug/run *.d -L-L. -debug -debug=TDD -I../Jeca -I../OtherPeoples/dallegro5
